add =() =>{
    let number1 = document.getElementById("num1").value;
    let number2 = document.getElementById("num2").value;
    let sum = number1 + number2;
    document.getElementById("result").innerHTML = sum;
}

clearVal =() =>{
    document.getElementById("num1").value = "";
    document.getElementById("num2").value = "";
    document.getElementById("result").innerHTML = "";
}